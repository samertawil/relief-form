 
        function hidde() {
            $('.hidden').css('display','none');
        };
    
       $(window).on('load',function(){
      
          hidde();
       })
     
 